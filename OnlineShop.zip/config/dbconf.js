module.exports = {
    protocol: 'mongodb',
    server: 'localhost',
    port: '27017',
    dbname: 'kindersdb'
};